#!/bin/bash

# This Script using the soxi command (available with the SOX tool) show the metadata associated with the selected Audio file.
# NOTE: this script work only with Audio files supported by sox/soxi


# Error messages to show if Zenity or soxi commands are not available
noZenityFound="Please, install the zenity package before run the script !"
noSoxiCommandFound="Please, install sox and soxi utility before run the script !"


# Check if the zenity package is installed
which zenity
if [ ! $? = 0 ]; then
   echo "$noZenityFound" > /tmp/Audio-Info-error
   xdg-open /tmp/Audio-Info-error
   exit
fi

 

# The full path of the selected file (eg: /home/fulvio/afile.mp3) That path will be used as input for the soxi command
# Note: NAUTILUS_SCRIPT_SELECTED_FILE_PATHS is an input variable initialized by Nautilus
fullFolderPath=${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS}

# The use of " is necesary to preserves whitespace in a single variable because a folder name can have white spaces
#f=`ls -i "$fullFolderPath"`
f=`ls -i $fullFolderPath | grep "$1" | awk '{print $1}'`

#f=`ls -i  $fullFolderPath`
 
 


#echo "39552041" | sudo -S  debugfs -R "stat <13394652>" /dev/sda7 |zenity --text-info
#szAnswer=$(zenity --entry --text "where are you?" --entry-text "at home");

#sudo|gksu -m 'password' -p | debugfs -R 'stat <22674>' /dev/loop0| zenity --text-info

#echo "39552041" | sudo -S  debugfs -R "stat $f" /dev/loop0 |zenity --text-info
echo "39552041" | sudo -S  debugfs -R "stat <$f>" /dev/sda7 |zenity --text-info

#sudo < 'sudo'  | debugfs -R 'stat <22674>' /dev/loop0| zenity --text-info

 #debugfs -R 'stat <22674>' /dev/loop0 
 
 #gksu

 #echo 'djfdklfj' |zenity --text-info

 #sudo debugfs -R 'stat 文件名' /dev/loop0

# DEBUG: 
 #zenity --info --text "$f"


# Check if the user has chosen a file with the right click (eg folder are not allowed)
 
   	   # zenity --error --text="File format not supported ! \n See: http://sox.sourceforge.net/Docs/Features \n for supported format"
	 
	   # zenity --text-info --title="Audio File Metadata (Read Only)" --filename=$LOGFILE --width=550 --height=450	

	   
 
 
 

 
 
